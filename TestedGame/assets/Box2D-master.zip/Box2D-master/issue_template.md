Make sure these boxes are checked before submitting your issue - thank you!

- [ ] If you need help, first ask for help on [discord](https://discord.gg/NKYgCBP) and [sub-reddit](https://www.reddit.com/r/box2d) first.
- [ ] Please consider providing a dump file using b2World::Dump.
